# skin care > 2023-11-28 11:52am
https://universe.roboflow.com/skin-care-9z8v8/skin-care-clfld

Provided by a Roboflow user
License: CC BY 4.0

